RPi
===

A Minetest game tuned to be used for Pixel Art and other creative work on low end hardware. Specially the Raspberry Pi.

This game is in it's very early stages of development. So a lot of bugs and no needed things.
---------------------------------------------------------------------------------------------
