peaceful_npc
============

Adds peaceful npcs. They do not attack you. They can jump and open doors unles the doors are locked. There is an automatic spawner.
