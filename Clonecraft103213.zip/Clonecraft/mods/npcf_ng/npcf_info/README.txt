Mod - Info NPC [npcf_info]
--------------------------

License Source Code: 2013 Stuart Jones - LGPL v2.1

License Textures: WTFPL

Depends: npcf

The Info NPC is a simple information serving character. You could think of them as a
human book providing information about a particular server location, or whatever else you like.
Supports multiple pages of text. 12 lines per page, ~50 chars per line.

