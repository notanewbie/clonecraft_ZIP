aliveai={
	character_model="character.b3d",	--character model
	status=false,			--show bot status
	tools=1,				--hide bot tools
	max_num=50,			--max bots
	max_num_by_self=7,		--max spawned bots by self
	active={},
	msg={},
	regulate_prestandard=0,
	smartshop=minetest.get_modpath("smartshop")~=nil,
				--staplefood database, add eatable stuff to the list, then can all other bots check if them have something like that to eat when they gets hurted
	staplefood=		{["default:apple"]=1,["farming:bread"]=1,["mobs:meat"]=1,["mobs:meat_raw"]=1,},
	furnishings=		{"default:chest","default:furnace","default:chest_locked","default:sign_wall_wood","default:sign_wall_steel","vessels:steel_bottle","vessels:drinking_glass","vessels:glass_bottle"},
	basics=			{"default:desert_stone","default:sandstonebrick","default:sandstone","default:snowblock","default:ice","default:dirt","default:sand","default:desert_sand","default:silver_sand","default:stone","default:leaves"},
	windows=		{"default:glass"},
	ladders=			{"default:ladder_wood","default:ladder_steel"},
	standard={"w","s"},	--short names/group (wood stone) have to be added to the "aliveai.namecut" and "aliveai.newneed"
}
dofile(minetest.get_modpath("aliveai") .. "/base.lua")
dofile(minetest.get_modpath("aliveai") .. "/event.lua")
dofile(minetest.get_modpath("aliveai") .. "/other.lua")
dofile(minetest.get_modpath("aliveai") .. "/items.lua")
dofile(minetest.get_modpath("aliveai") .. "/missions.lua")
dofile(minetest.get_modpath("aliveai") .. "/chat.lua")
dofile(minetest.get_modpath("aliveai") .. "/bot.lua")

aliveai.create_bot()								-- create standard bots
aliveai.create_bot({							-- create standard bots 2
		attack_players=1,
		name="bot2",
		team="Jezy",
		texture="aliveai_skin2.png",
		stealing=1,
		steal_chanse=5,
})





--print(debug.getinfo(2).name)				-- get name from calling function


minetest.register_chatcommand("aliveai", {
	params = "",
	description = "aliveai settings",
	privs = {server=true},
	func = function(name, param)
		if string.find(param,"status=true")~=nil then
			aliveai.status=true
			minetest.chat_send_player(name, "<aliveai> bot status on")
		elseif string.find(param,"status=false")~=nil then
			aliveai.status=false
			minetest.chat_send_player(name, "<aliveai> bot status off")
		end
	end
})
print("[aliveai] mod loaded")