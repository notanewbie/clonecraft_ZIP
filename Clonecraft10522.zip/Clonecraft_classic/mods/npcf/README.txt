Mintest Modpack - NPC Framework [minetest-npcf]
===============================================
Version: 0.1.0

License of Source Code: LGPL
----------------------------
(c) Copyright Stuart Jones, 2013

License of Textures: WTFPL
--------------------------
(c) Copyright Stuart Jones, 2013

NPC Framework [npcf]
====================
This mod adds some, hopefully useful, non-player characters to the minetest game. The mod also provides a framework for others to create and manage their own custom NPCs.

Additional Text Colors [textcolors]
===================================
This mod adds colored text for NPC nametags. Can be safely removed to save space, NPC nametags will only use the default white text supplied by npcf itself.

