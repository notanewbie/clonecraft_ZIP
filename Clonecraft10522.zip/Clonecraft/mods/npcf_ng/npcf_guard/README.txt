Mod - Guard NPC [npcf_guard]
----------------------------

License Source Code: 2013 Stuart Jones - LGPL v2.1

License Textures: WTFPL

Depends: npcf

Protect yourself and your property against other players and mobs. Features 3d weapon and armor.
Can be left to guard a certain area or set to follow their owner.

