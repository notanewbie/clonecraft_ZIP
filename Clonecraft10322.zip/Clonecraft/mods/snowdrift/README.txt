snowdrift 0.3.0 by paramat
For latest stable Minetest and back to 0.4.9 dev after 13/01/14
Depends default
Licenses: code WTFPL, textures CC BY-SA
