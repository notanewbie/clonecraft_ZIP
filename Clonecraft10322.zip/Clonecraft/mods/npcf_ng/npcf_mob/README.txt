Mod - Mob NPC [npcf_mob]
--------------------------

License Source Code: 2013 Stuart Jones - LGPL v2.1

License Textures: 2013 Stuart Jones - WTFPL

Depends: npcf, tnt

A rare but very destructive 'Mushroom Man' mob

