Mod - Builder NPC [npcf_builder]
--------------------------------

License Source Code: 2013 Stuart Jones - LGPL v2.1

License Textures: WTFPL

Depends: npcf

Not really much point to this atm other than it's really fun to watch. By default, it be can only
build a basic hut, however this is compatible (or so it seems) with all the schematics provided by
Dan Duncombe's instabuild mod. These should be automatically available for selection if you have
the instabuild mod installed.

