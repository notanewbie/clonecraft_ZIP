
aliveai.bot=function(self, dtime)
	self.timer=self.timer+dtime
	self.timerfalling=self.timerfalling+dtime
	if self.timerfalling>0.2 then aliveai.falling(self) end
	if self.timer<=self.time then return self end
	self.timer=0
	if aliveai.regulate_prestandard>0 and math.random(1,aliveai.regulate_prestandard)==1 then return self end
--betweens
	if not aliveai.dmgbynode(self) then return self end
	aliveai.jumping(self)-- if need to jump
	aliveai.msghandler(self)
	if aliveai.come(self) then return self end
	if aliveai.fight(self) then return self end
	if aliveai.fly(self) then return self end
	if aliveai.light(self) then return self end
	if self.step(self,dtime) then return self end
	aliveai.pickup(self)-- if can pick up items
--betweens helpers
	if self.isrnd and self.pickupgoto then return self end
--events
	if self.mine then
		aliveai.mine(self)
		return self
	end
	if self.findspace then
		aliveai.findspace(self)
		return self
	end
	if self.build then
		aliveai.build(self)
		return self
	end
--missions
	if self.mission=="build" then
		aliveai.mission_build(self)
		return self
	end
--mission create
	if self.building==1 and self.mission=="" and not self.home then			--setting up for build a home
		self.build_step=1
		self.build_pos=""
		self.mission="build"
		self.ignoremineitem=""
		self.ignoreminetime=0
		self.ignoreminetimer=200
		self.ignoreminechange=0
		self.missionstep=0
		aliveai.rndwalk(self,false)				-- stop rnd walking
		return self
	end

	if self.mission=="" then
		aliveai.rndwalk(self)
	end
	return self
end


aliveai.do_nothing=function(self)
	return
end

aliveai.create_bot=function(def)
	if not def then def={} end
	def.name=def.name or "bot"
	def.mod_name=minetest.get_current_modname()
	if aliveai.smartshop and def.on_step==nil then def.on_step=aliveai.use_smartshop end
	if not def.on_click then def.on_click=aliveai.give_to_bot end


minetest.register_craftitem(def.mod_name ..":" .. def.name .."_spawner", {
	description = def.name .." spawner",
	inventory_image = def.texture or "character.png",
		on_place = function(itemstack, user, pointed_thing)
			if pointed_thing.type=="node" then
				local pos=aliveai.roundpos(pointed_thing.above)
				pos.y=pos.y+0.5
				minetest.env:add_entity(pos, def.mod_name ..":" .. def.name):setyaw(math.random(0,6.28))
				itemstack:take_item()
			end
			return itemstack
		end,
	})
	def.drop_dead_body=def.drop_dead_body or 1
	if def.texture~=nil then def.texture={def.texture} end

if def.drop_dead_body==1 then
minetest.register_entity(def.mod_name ..":" .. def.name .."_dead",{
	hp_max = def.hp or 20,
	physical = true,
	weight = 5,
	collisionbox = {-0.35,-1.0,-0.35,0.35,-0.4,0.35},
	visual = "mesh",
	visual_size = def.visual_size or {x=1,y=1},
	mesh = aliveai.character_model,
	textures = def.texture or {"character.png"},
	colors = {},
	spritediv = {x=1, y=1},
	initial_sprite_basepos = {x=0, y=0},
	is_visible = true,
	makes_footstep_sound = true,
	automatic_rotate = false,
	on_activate=function(self, staticdata)
		aliveai.anim(self,"lay")
		self.object:setacceleration({x=0,y=-10,z =0})
		self.object:setvelocity({x=0,y=-3,z =0})
		return self
	end,
	on_step=function(self, dtime)
		self.time=self.time+dtime
		if self.time<5 then return self end
		local pos=self.object:getpos()
		pos.y=pos.y-1
		local node=minetest.get_node(pos)
		aliveai.punch(self,self.object,self.object:get_hp()*2)
		if node and minetest.get_node_group(node.name, "igniter")>0 then
		minetest.add_particlespawner({
			amount = 10,
			time =0.2,
			minpos = {x=pos.x-1, y=pos.y, z=pos.z-1},
			maxpos = {x=pos.x+1, y=pos.y, z=pos.z+1},
			minvel = {x=0, y=0, z=0},
			maxvel = {x=0, y=math.random(3,6), z=0},
			minacc = {x=0, y=2, z=0},
			maxacc = {x=0, y=0, z=0},
			minexptime = 1,
			maxexptime = 3,
			minsize = 3,
			maxsize = 8,
			texture = "default_item_smoke.png",
			collisiondetection = true,
		})
		end
		return self
	end,
	time=0,
	type="",
	anim=""
})
end


minetest.register_entity(def.mod_name ..":" .. def.name,{
	hp_max = def.hp or 20,
	physical = true,
	weight = 5,
	collisionbox = def.collisionbox or {-0.35,-1.0,-0.35,0.35,0.8,0.35},
	visual = "mesh",
	visual_size = def.visual_size or {x=1,y=1},
	mesh = aliveai.character_model,
	textures = def.texture or {"character.png"},
	colors = {},
	spritediv = {x=1, y=1},
	initial_sprite_basepos = {x=0, y=0},
	is_visible = true,
	makes_footstep_sound = true,
	automatic_rotate = false,
on_rightclick=function(self, clicker,name)
		self.on_click(self,clicker)
	end,
on_punch=function(self, puncher, time_from_last_punch, tool_capabilities, dir)
		if dir~=nil then
			self.object:setvelocity({x = dir.x*3,y = self.object:getvelocity().y,z = dir.z*3})
		end
		aliveai.showhp(self)
		if self.object:get_hp()<=0 then
			local pos=self.object:getpos()
			aliveai.invdropall(self)
			if self.drop_dead_body==1 then
				minetest.env:add_entity(pos, def.mod_name ..":" .. def.name .."_dead"):setyaw(self.object:getyaw())
			end
			self.on_death(self,puncher,pos)
			aliveai.max(self,true)
			return self
		end


		self.punched(self,puncher)

		aliveai.showhp(self)
		if self.path then
			aliveai.exitpath(self)
		end
		minetest.after(2, function(self)
			aliveai.eat(self,"")
		end,self)
		if not (puncher:get_luaentity() and puncher:get_luaentity().aliveai and puncher:get_luaentity().botname==self.botname) then
			local known=aliveai.getknown(self,puncher)
			if known=="member" then
				aliveai.known(self,puncher,"")
				aliveai.say(self,"I dont like you anymore")
				return self
			elseif self.escape==1 and known=="fly" or self.fighting~=1 then
				if self.temper>-5 then
					self.temper=self.temper-0.3
				end
				aliveai.sayrnd(self,"ahh")
				self.fly=puncher
			elseif self.fighting==1 then
				if self.temper<5 then
					self.temper=self.temper+1
				end
				self.fight=puncher
				aliveai.sayrnd(self,"ouch")
			end
			return self
		end
		aliveai.sayrnd(self,"ouch")
		return self
	end,
on_activate=function(self, staticdata)
		if staticdata~="" then
			local r=aliveai.convertdata(staticdata)
			self.inv={}
			self.ignore_item={}
			self.ignore_nodes={}
			self.known={}
			self.start_with_items={}
			self.old=r.old
			self.known=r.known
			self.inv=r.inv
			self.ignore_item=r.ignore_item
			self.ignore_nodes=r.ignore_ingnore_nodes
			self.mission=r.mission
			self.missionstep=r.missionstep
			self.botname=r.botname
			self.start_with_items=r.start_with_items
			self.dmg=r.dmg 
			if r.savetool then self.tools=r.tools self.savetool=1 self.tool_near=1 end
			if r.home then self.home=r.home end
			if r.resources then self.resources=r.resources end
			if r.hp then self.object:set_hp(r.hp) end
			if self.mission=="build" then
				self.house=r.house
				self.build_step=r.build_step
				self.build_x=r.build_x
				self.build_y=r.build_y
				self.build_z=r.build_z
				self.build_pos=r.build_pos
				self.ignoremineitem=r.ignoremineitem
				self.ignoreminetime=tonumber(r.ignoreminetime)
				self.ignoreminetimer=tonumber(r.ignoreminetimer)
				self.ignoreminechange=tonumber(r.ignoreminechange)
			end
		end
		if self.inv==nil then self.inv={} end
		if self.ignore_item==nil  then self.ignore_item={} end

		self.move={x=0,y=0,z=0,speed=1}
		aliveai.anim(self,"stand")
		self.object:setacceleration({x=0,y=-10,z =0})
		self.object:setvelocity({x=0,y=-5,z =0})
		if self.botname=="" then self.botname=aliveai.genname() end
		if self.namecolor~="" then self.object:set_properties({nametag=self.botname,nametag_color="#" .. self.namecolor}) end
		if self.start_with_items~="" and type(self.start_with_items)=="table" then
			for i, s in pairs(self.start_with_items) do
				aliveai.invadd(self,i,s,true)
			end
		end
		aliveai.max(self)
		return self
	end,
get_staticdata = function(self)
		local r={inv=self.inv,old=1,hp=self.object:get_hp(),
			mission=self.mission,
			missionstep=self.missionstep,
			ignore_item=self.ignore_item,
			known=self.known,
			ignore_nodes=self.ignore_ingnore_nodes,
			botname=self.botname,
			start_with_items=self.start_with_items,
			dmg=self.dmg,
			}
		if self.home then r.home=self.home end
		if self.resources then r.resources=self.resources end
		if self.savetool then r.tools=self.tools r.savetool=1 end
		if self.mission=="build" then
			r.house=self.house
			r.build_step=self.build_step
			r.build_x=self.build_x
			r.build_y=self.build_y
			r.build_z=self.build_z
			r.build_pos=self.build_pos
			r.ignoremineitem=self.ignoremineitem
			r.ignoreminechange=self.ignoreminechange
			r.ignoreminetime=self.ignoreminetime
			r.ignoreminetimer=self.ignoreminetimer
		end
		self.on_spawn(self)
		return aliveai.convertdata(r)
	end,
on_step=aliveai.bot,
	on_spoken_to= def.on_spoken_to or aliveai.on_spoken_to,
	old=0,
	botname=def.botname or "",
	dmg= def.dmg or 4,
	namecolor= def.name_color or "ffffff",
	temper= 0,
	rnd= 0,
	isrnd= false,
	arm= def.arm or 5,
	done="",
	avoidy= def.avoid_height or 6,
	missionstep= 0,
	mission= "",
	house=def.house or "",
	pathn= 1,
	anim= "",
	timer= 0,
	time= 1,
	otime= 1,
	timer3= 0,
	timerfalling= 0,
	aliveai= true,
	drop_dead_body=def.drop_dead_body or 1,
	team= def.team or "Sam",
	type= def.type or "npc",
	distance= def.distance or 15,
	tools= def.tools or "",
	tool_index=def.tool_index or 1,
	tool_reuse=def.tool_reuse or 0,
	tool_chance= def.tool_chance or 5,
	tool_see= def.tool_see or 1,
	tool_near= def.tool_near or 0,
	escape= def.escape or 1,
	fighting= def.fighting or 1,
	attack_players= def.attack_players or 0,
	smartfight= def.smartfight or 1,
	building= def.building or 1,
	pickuping= def.pickuping or 1,
	attacking= def.attacking or 0,
	coming= def.coming or 1,
	coming_players= def.coming_players or 1,
	talking= def.talking or 1,
	stealing= def.stealing or 0,
	steal_chanse= def.steal_chanse or 0,
	start_with_items= def.start_with_items or "",
	light= def.light or 1,
	lowestlight= def.lowest_light or 10,
	lightdamage=def.hurts_by_light or 1,
	on_fighting= def.on_fighting or aliveai.do_nothing,
	on_escaping= def.on_escaping or aliveai.do_nothing,
	on_punching= def.on_punching or aliveai.do_nothing,
	on_detect_enemy= def.on_detect_enemy or aliveai.do_nothing,
	on_detecting_enemy= def.on_detecting_enemy or aliveai.do_nothing,
	on_death= def.on_death or aliveai.do_nothing,
	on_spawn= def.on_spawn or aliveai.do_nothing,
	on_random_walk= def.on_random_walk or aliveai.do_nothing,
	on_click= def.on_click or aliveai.do_nothing,
	punched= def.on_punched or aliveai.do_nothing,
	on_meet= def.on_meet or aliveai.do_nothing,
	step= def.on_step or aliveai.do_nothing,
	on_dig= def.on_dig or aliveai.do_nothing,
})

def.spawn_in= def.spawn_in or "air"
def.spawn_chance= def.spawn_chance or 1000

if def.light==nil then def.light=1 end
if def.lowest_light==nil then def.lowest_light=10 end

minetest.register_abm({
	nodenames = def.spawn_on or {"group:dirt","group:sand","default:snow"},
	interval = def.spawn_interval or 300,
	chance = def.spawn_chance,
	action = function(pos)
		local pos1={x=pos.x,y=pos.y+1,z=pos.z}
		local pos2={x=pos.x,y=pos.y+2,z=pos.z}
		local l=minetest.get_node_light(pos1)
		if l==nil then return true end
		if math.random(1,def.spawn_chance)==1
		and (def.light==0 
		or (def.light>0 and l>=def.lowest_light) 
		or (def.light<0 and l<=def.lowest_light))
		and minetest.get_node(pos1).name==def.spawn_in
		and minetest.get_node(pos2).name==def.spawn_in then
			aliveai.newbot=true
			minetest.env:add_entity(pos1, def.mod_name ..":" .. def.name):setyaw(math.random(0,6.28))
		end
	end,
})
print("[aliveai] loaded: " .. def.mod_name ..":" .. def.name)
end