if minetest.get_modpath("nitroglycerine")~=nil then
aliveai.create_bot({
		drop_dead_body=0,
		attack_players=1,
		name="nitrogen",
		team="ice",
		texture="aliveai_threats_nitrogen.png",
		stealing=1,
		steal_chanse=2,
		attacking=1,
		talking=0,
		light=0,
		building=0,
		escape=0,
		start_with_items={["default:snowblock"]=1,["default:ice"]=4},
		type="monster",
		dmg=1,
		hp=40,
		name_color="",
		arm=2,
		spawn_on={"default:silver_sand","default:dirt_with_snow","default:snow","default:snowblock","default:ice"},
	on_step=function(self,dtime)
		local pos=self.object:getpos()
		pos.y=pos.y-1.5
		local node=minetest.get_node(pos)
		if node and node.name and minetest.is_protected(pos,"")==false then
			if minetest.get_node_group(node.name, "soil")>0 then
				minetest.set_node(pos,{name="default:dirt_with_snow"})
			elseif minetest.get_node_group(node.name, "sand")>0  and minetest.registered_nodes["default:silver_sand"] then
				minetest.set_node(pos,{name="default:silver_sand"})
			elseif minetest.get_node_group(node.name, "water")>0 then
				minetest.set_node(pos,{name="default:ice"})
				pos.y=pos.y+1
				if minetest.get_node_group(minetest.get_node(pos).name, "water")>1 then
					minetest.set_node(pos,{name="default:ice"})
				end
			elseif minetest.get_node_group(node.name, "lava")>0 then
				minetest.set_node(pos,{name="default:ice"})
				pos.y=pos.y+1
				if minetest.get_node_group(minetest.get_node(pos).name, "lava")>1 then
					minetest.set_node(pos,{name="default:ice"})
				end
			end
		end
	end,
	on_punching=function(self,target)
		if aliveai.gethp(target)<=self.dmg+5 then
			aliveai_nitroglycerine.freeze(target)
		else
			target:punch(self.object,1,{full_punch_interval=1,damage_groups={fleshy=self.dmg}},nil)
		end
	end,
	on_death=function(self,puncher,pos)
		minetest.sound_play("default_break_glass", {pos=pos, gain = 1.0, max_hear_distance = 5,})
		aliveai_nitroglycerine.crush(pos)
	end,
})

aliveai.create_bot({
		drop_dead_body=0,
		attack_players=1,
		name="gassman",
		team="nuke",
		texture="aliveai_threats_gassman.png",
		attacking=1,
		talking=0,
		light=0,
		building=0,
		escape=0,
		--start_with_items={["default:snowblock"]=1,["default:ice"]=4},
		type="monster",
		dmg=0,
		hp=100,
		name_color="",
		arm=2,
		coming=0,
		smartfight=0,
		spawn_on={"group:sand","group:soil","default:gravel"},
	on_fighting=function(self,target)
		if not self.ti then self.ti={t=1,s=0} end
		self.temper=10
		self.ti.s=self.ti.s-1
		if self.ti.s<=0 then
			self.ti.t=self.ti.t-1
			if self.ti.t>=0 then
				self.ti.s=99
			end
		end
		if self.ti.t<0 then
			local pos=self.object:getpos()
			self.object:punch(self.object,1,{full_punch_interval=1,damage_groups={fleshy=self.object:get_hp()*2}},nil)
			aliveai_nitroglycerine.explode(pos,{
				radius=10,
				set="air",
				drops=0,
			})
			return self
		end

		local tag=self.ti.t ..":" .. self.ti.s
		self.object:set_properties({nametag=tag,nametag_color="#ff0000aa"})
	end,
	on_death=function(self,puncher,pos)
			if not self.ex then
				self.ex=true
				aliveai_nitroglycerine.explode(pos,{
				radius=2,
				set="air",
				})
			end
			return self
	end,
})



aliveai.create_bot({
		drop_dead_body=0,
		attack_players=1,
		name="nitrogenblow",
		team="ice",
		texture="aliveai_threats_nitrogenblow.png",
		attacking=1,
		talking=0,
		light=0,
		building=0,
		escape=0,
		start_with_items={["default:snowblock"]=10,["default:ice"]=2},
		spawn_on={"default:silver_sand","default:dirt_with_snow","default:snow","default:snowblock","default:ice"},
		type="monster",
		dmg=1,
		hp=30,
		name_color="",
		arm=2,
		coming=0,
		smartfight=0,
		spawn_on={"group:sand","group:soil","default:gravel"},
	on_fighting=function(self,target)
		if aliveai.gethp(target)<=self.dmg+5 then
			aliveai_nitroglycerine.freeze(target)
		elseif math.random(1,10)==1 then
			target:punch(self.object,1,{full_punch_interval=1,damage_groups={fleshy=self.dmg}},nil)
		end
		if not self.ti then self.ti={t=5,s=9} end
		self.temper=10
		self.ti.s=self.ti.s-1
		if self.ti.s<=0 then
			self.ti.t=self.ti.t-1
			if self.ti.t>=0 then
				self.ti.s=9
			end
		end
		if self.ti.t<0 then
			self.ex=true
			if aliveai.gethp(target)<=11 then
				aliveai_nitroglycerine.freeze(target)
			else
				target:punch(self.object,1,{full_punch_interval=1,damage_groups={fleshy=10}},nil)
			end
			aliveai_nitroglycerine.crush(self.object:getpos())
			self.object:punch(self.object,1,{full_punch_interval=1,damage_groups={fleshy=self.object:get_hp()*2}},nil)
			return self
		end
		local tag=self.ti.t ..":" .. self.ti.s
		self.object:set_properties({nametag=tag,nametag_color="#ff0000aa"})
	end,
	on_death=function(self,puncher,pos)
			minetest.sound_play("default_break_glass", {pos=pos, gain = 1.0, max_hear_distance = 5,})
			if not self.ex then
				self.ex=true
				self.aliveai_ice=1
				local radius=10
				aliveai_nitroglycerine.explode(pos,{
					--drops=0,
					--velocity=0,
					radius=radius,
					hurt=0,
					place={"default:snowblock","default:ice","default:snowblock"},
					place_chance=2,
				})

				for _, ob in ipairs(minetest.env:get_objects_inside_radius(pos, radius*2)) do
					local pos2=ob:getpos()
					local d=math.max(1,vector.distance(pos,pos2))
					local dmg=(8/d)*radius
					local en=ob:get_luaentity()
					if ob:is_player() or not (en and en.name=="aliveai_nitroglycerine:ice" or en.aliveai_ice) then
						if ob:get_hp()<=dmg+5 then
							nitroglycerine.freeze(ob)
						else
							ob:punch(ob,1,{full_punch_interval=1,damage_groups={fleshy=dmg}},nil)
						end
					end
				end
			end
			return self
	end,
})
end

aliveai.create_bot({
		attack_players=1,
		name="terminator",
		team="nuke",
		texture="aliveai_threats_terminator.png",
		attacking=1,
		talking=0,
		light=0,
		building=0,
		escape=0,
		start_with_items={["default:steel_ingot"]=4,["default:steelblock"]=1},
		type="monster",
		dmg=0,
		hp=200,
		arm=3,
		name_color="",
		spawn_on={"group:sand","group:soil","default:gravel"},
	on_punching=function(self,target)
		local pos=self.object:getpos()
		pos.y=pos.y-0.5
		local radius=self.arm
		for _, ob in ipairs(minetest.env:get_objects_inside_radius(pos, radius)) do
			local pos2=ob:getpos()
			local d=math.max(1,vector.distance(pos,pos2))
			local dmg=(8/d)*radius
			local en=ob:get_luaentity()
			if ob:is_player() or not (en and en.team==self.team or ob.itemstring) then
				if en then
					if en.type~="" then ob:punch(ob,1,{full_punch_interval=1,damage_groups={fleshy=dmg}},nil) end
					dmg=dmg*2
					ob:setvelocity({x=(pos2.x-pos.x)*dmg, y=((pos2.y-pos.y)*dmg)+2, z=(pos2.z-pos.z)*dmg})
				else
					
					ob:punch(ob,1,{full_punch_interval=1,damage_groups={fleshy=dmg}},nil)
					local d=dmg/2
					local v=0
					local dd=0
					local p2={x=pos.x-pos2.x, y=pos.y-pos2.y, z=pos.z-pos2.z}
					local tmp
					for i=0,10,1 do
						dd=d*v
						tmp={x=pos.x+(p2.x*dd), y=pos.y+(p2.y*dd)+2, z=pos.z+(p2.z*dd)}
						local n=minetest.get_node(tmp)
						if n and n.name and minetest.registered_nodes[n.name].walkable then
							if minetest.is_protected(tmp,"")==false and minetest.dig_node(tmp) then
								for _, item in pairs(minetest.get_node_drops(n.name, "")) do
									if item then
										local it=minetest.add_item(tmp, item)
										it:get_luaentity().age=890
										it:setvelocity({x = math.random(-1, 1),y=math.random(-1, 1),z = math.random(-1, 1)})
									end
								end
							else
								break
							end
						end
						v=v-0.1
					end
					d=d*v
					ob:setpos({x=pos.x+(p2.x*d), y=pos.y+(p2.y*d)+2, z=pos.z+(p2.z*d)})
				end
			end
		end
	end,
	on_spawn=function(self)
		self.hp2=self.object:get_hp()
	end,
	on_punched=function(self,puncher)
		if self.hp2-self.object:get_hp()<5 then
			self.object:set_hp(self.hp2)
			return self
		end
		local pos=self.object:getpos()
			minetest.add_particlespawner({
			amount = 5,
			time =0.05,
			minpos = pos,
			maxpos = pos,
			minvel = {x=-2, y=-2, z=-2},
			maxvel = {x=1, y=0.5, z=1},
			minacc = {x=0, y=-8, z=0},
			maxacc = {x=0, y=-10, z=0},
			minexptime = 2,
			maxexptime = 1,
			minsize = 0.1,
			maxsize = 2,
			texture = "default_steel_block.png",
			collisiondetection = true,
		})
	end
})