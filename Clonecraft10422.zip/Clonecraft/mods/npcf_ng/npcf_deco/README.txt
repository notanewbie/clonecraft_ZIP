Mod - Deco NPC [npcf_deco]
--------------------------

License Source Code: 2013 Stuart Jones - LGPL v2.1

License Textures: WTFPL

Depends: npcf

A purely decorative NPC, can be set to roam freely and/or follow random players it encounters.

